<?php

namespace Guzzle\Http\Exception;

class TooManyRedirectsException extends BadResponseException {}
